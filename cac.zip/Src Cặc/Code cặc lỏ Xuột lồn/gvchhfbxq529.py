#!/bin/NguyenDucMinh/VN/Python3
#Deobfuscator by Tool Crack
#============================

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Zalo - Nhắn Gửi Yêu Thương (Nhắn tin thoại - Trò chuyện nhóm ...)</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="format-detection" content="telephone=no">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
        <meta property="og:image" content="https://stc-zaloprofile.zdn.vn/pc/v1/images/zalo_logo_new.jpg"/>
        <link type="image/x-icon" href="https://stc-zaloprofile.zdn.vn/favicon.ico" rel="shortcut icon"/>
        <meta property="og:image" content="https://stc-zaloprofile.zdn.vn/images/default_thumb.png" />
        <link href="https://stc-zaloprofile.zdn.vn/pc/v1/css/layout.css" rel="stylesheet" type="text/css">
        <link href="https://stc-zaloprofile.zdn.vn/pc/v1/css/custom.css" rel="stylesheet" type="text/css">
        <script src="https://stc-zaloprofile.zdn.vn/pc/v1/js/jquery.min.js"></script>
        <script src='https://www.google.com/recaptcha/api.js'></script>
    </head>
    <body class="has-bg" style="height: 100vh;">
        <div class="scroll-to-top"></div>
        <div canvas="container">
            <div class="wrapper">
                <div class="zalo-layout">
                    <section class="body">
                        <div class="body-container">
                            <div class="module-page" style="min-height: auto">
                                <form method="post">
                                    <h2>Kiểm tra bảo mật</h2>
                                    <p>Để tránh việc spam hay thu thập thông tin trái phép, vui lòng xác minh bạn không phải là robot.</p>
                                    <div style="margin-bottom: 30px" class="line-form g-recaptcha" data-sitekey="6LfnGa4UAAAAAKtyxlWWyYtrVx-0O6pziBP9XInL"></div>
                                    <button id="btnSubmit" type="submit" class="btn btn-primary btn--l">Xác Minh</button>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </body>
</html>
