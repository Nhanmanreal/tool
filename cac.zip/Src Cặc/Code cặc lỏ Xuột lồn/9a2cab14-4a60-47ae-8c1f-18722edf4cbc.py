#!/bin/NguyenDucMinh/VN/Python3
#Deobfuscator by Tool Crack
#============================

print('')