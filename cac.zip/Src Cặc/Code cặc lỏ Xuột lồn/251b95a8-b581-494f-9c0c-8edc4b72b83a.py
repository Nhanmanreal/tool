#!/bin/NguyenDucMinh/VN/Python3
#Deobfuscator by Tool Crack
#============================


luc = "\033[1;32m"
trang = "\033[1;37m"
do = "\033[1;31m"
vang = "\033[0;93m"
hong = "\033[1;35m"
xduong = "\033[1;34m"
xnhac = "\033[1;36m"
# Đánh Dấu Bản Quyền
vchh_tool = do + "[" + trang + "=))" + do + "] " + trang + "=> "
vchh = do + "[" + trang + "=))" + do + "] " + trang + "=> "
# import lib
import requests, threading
import os, sys
from time import sleep
from datetime import datetime
try:
	import requests,pystyle
except:
	print (luc + "Bạn Chưa Tải Thư Viện \n Bắt Đầu Tải ")
	os.system('pip install requests && pip install bs4 && pip install pystyle')
# ==========================[ FUNCTION ]===========================================
def echo(a):
   for i in range(len(a)):
     sys.stdout.write(a[i])
     sys.stdout.flush()
     sleep(0.001)
   print()
def banner():
    banner = f"""
\033[1;35m██╗  ██╗██╗   ██╗██╗   ██╗██╗  ██╗ ██████╗  █████╗ ███╗   ██╗ ██████╗   
\033[1;37m██║  ██║██║   ██║╚██╗ ██╔╝██║  ██║██╔═══██╗██╔══██╗████╗  ██║██╔════╝     
\033[1;35m███████║██║   ██║ ╚████╔╝ ███████║██║   ██║███████║██╔██╗ ██║██║  ███╗    
\033[1;37m██╔══██║██║   ██║  ╚██╔╝  ██╔══██║██║   ██║██╔══██║██║╚██╗██║██║   ██║
\033[1;35m██║  ██║╚██████╔╝   ██║   ██║  ██║╚██████╔╝██║  ██║██║ ╚████║╚██████╔
\033[1;37m╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ 
\033[1;31m────────────────────────────────────────────────────────────
\033[1;31m[\033[1;37m=))\033[1;31m] \033[1;37m=> \033[1;33mTOOL GET TOKEN PRO5
\033[1;31m[\033[1;37m=))\033[1;31m] \033[1;37m=> \033[1;35mADMIN: \033[1;36mVũ Công Huy Hoàng
\033[1;31m[\033[1;37m=))\033[1;31m] \033[1;37m=> \033[1;36mFB: \033[1;31mhuyhoang.x.dev
\033[1;31m[\033[1;37m=))\033[1;31m] \033[1;37m=> \033[1;32mBOX SUPPORT: \033[1;37mhttps://zalo.me/g/wnussp467
\033[1;31m[\033[1;37m=))\033[1;31m] \033[1;37m=> \033[1;34mYOUTUBE: \033[1;37mHuyHoangShareTool
\033[1;31m────────────────────────────────────────────────────────────"""
    echo(banner)
def clear():
    os.system("cls" if os.name == "nt" else "clear")
def thanh():
    print('\033[1;37m- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')
# =================[ CLEAR + THÔNG SỐ ADMIN ]===========================
clear()
banner()
token = input(vchh_tool+luc+'Vui Lòng Nhập Token Facebook'+trang+': '+vang)
thanh()
file_save = input(vchh_tool+luc+'Vui Lòng Nhập Tên File Muốn Lưu'+trang+': '+vang)
# JSON GET TOKEN PRO5+PAGE THƯỜNG
thanh()
get_token = requests.get('https://graph.facebook.com/me/accounts?access_token='+token).json()['data']
# RUN
for get in get_token:
    time = datetime.now().strftime("%H:%M:%S")
    dem = dem+1
    tokenpro5 = get['access_token']
    namepro5 = get["name"]
    idpro5 = get['id']
    print(''+do+'['+vang+str(dem)+do+'] | '+xnhac+str(time)+do+' | '+vang+'SUCCESS '+do+' | '+trang+str(idpro5)+do+' | '+trang+str(namepro5)+do+' | '+trang+str(tokenpro5)+'')
    thanh()
    open(''+file_save+'', "a+").write(f'{idpro5}|{tokenpro5}\n')
print(vchh_tool+do+'['+vang+'SUCCESS'+do+']'+trang+': '+luc+'Đã Lưu Thành Công Vào File, '+xnhac+file_save+' ')